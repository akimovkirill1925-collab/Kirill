Ultra Max V5 - Android Studio Project
====================================

What this contains:
- Full Android Studio project skeleton (Kotlin)
- Foreground MonitorService that polls BatteryManager and logs CSV
- Room DB schema for storing samples
- MainActivity with usage-access shortcut and start/stop controls
- BootReceiver to auto-start service after reboot

Important notes:
- This project is a skeleton; it implements core monitoring and logging.
- To access per-app battery stats in-depth you will need either:
  * root access (and use `dumpsys batterystats` or read /data/system files), or
  * special privileged permissions only available to system apps.
- Non-root mode uses BatteryManager and UsageStatsManager as proxies (foreground time).

Build steps:
1. Copy the project folder to your PC.
2. Open in Android Studio (Arctic Fox or later).
3. Sync Gradle (install missing SDK components if prompted).
4. Build -> Build APK(s).
5. Install via adb: adb install -r app/build/outputs/apk/debug/app-debug.apk

To enable Usage Access:
- Go to Settings -> Security -> Usage Access -> grant to Ultra Max.

Root mode (optional):
- If you have root and Magisk, the app can be extended to run `su -c "dumpsys batterystats --reset"` and parse outputs.
- I can add root helpers if you want.

If you want, I can:
A) add full per-app battery parsing via dumpsys (requires root) and include an optional Magisk helper.
B) prepare a release-signed APK (you'll need to provide a signing key).
C) build a debug-signed APK here (I cannot compile in this environment; I only provide sources).

