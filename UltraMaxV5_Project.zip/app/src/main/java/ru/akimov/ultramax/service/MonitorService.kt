package ru.akimov.ultramax.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import ru.akimov.ultramax.R
import ru.akimov.ultramax.ui.MainActivity
import java.lang.Exception

class MonitorService : Service() {
    private val CHANNEL_ID = "ultramax_channel"
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, buildNotification("Initializing..."))
        job = scope.launch {
            while (isActive) {
                collectOnce()
                delay(15_000)
            }
        }
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "UltraMax Monitor", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("UltraMax Monitor")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun collectOnce() {
        try {
            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val currentNow = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            val voltage = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_VOLTAGE)
            val ts = System.currentTimeMillis()
            // Save to local storage: use file in filesDir
            val logLine = "${'$'}{ts},${'$'}{level},${'$'}{currentNow},${'$'}{voltage}\n"
            openFileOutput("ultramax_log.csv", Context.MODE_APPEND).use { it.write(logLine.toByteArray()) }
            // update notification
            val notifText = "Lv:${level}% Cur:${if(currentNow==Int.MIN_VALUE) 0 else currentNow/1000}mA"
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(1, buildNotification(notifText))
        } catch(e: Exception) { e.printStackTrace() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
