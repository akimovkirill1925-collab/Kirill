package ru.akimov.ultramax.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface SampleDao {
    @Insert
    suspend fun insert(s: Sample)

    @Query("SELECT * FROM samples ORDER BY ts DESC LIMIT :limit")
    suspend fun last(limit: Int): List<Sample>
}
