package ru.akimov.ultramax.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val svc = Intent(context, ru.akimov.ultramax.service.MonitorService::class.java)
        ContextCompat.startForegroundService(context, svc)
    }
}
