package ru.akimov.ultramax.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "samples")
data class Sample(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ts: Long,
    val level: Int,
    val current: Int?,
    val voltage: Int?,
    val temp: Int?
)
