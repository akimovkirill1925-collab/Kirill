package ru.akimov.ultramax.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import ru.akimov.ultramax.R

class MainActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnUsage = findViewById<Button>(R.id.btn_usage)
        val btnStart = findViewById<Button>(R.id.btn_start)
        val btnStop = findViewById<Button>(R.id.btn_stop)
        val txtStatus = findViewById<TextView>(R.id.txt_status)

        btnUsage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        btnStart.setOnClickListener {
            startService(Intent(this, ru.akimov.ultramax.service.MonitorService::class.java))
            txtStatus.text = "Service started"
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, ru.akimov.ultramax.service.MonitorService::class.java))
            txtStatus.text = "Service stopped"
        }
    }
}
