package ru.akimov.ultramax.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Sample::class], version = 1)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): SampleDao
}
